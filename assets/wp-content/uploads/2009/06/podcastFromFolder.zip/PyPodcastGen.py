#!/usr/bin/env python

# Generates a podcast RSS feed from a folder of MP3 files
# By Kevin Yank <thatguy@kevinyank.com>
# Based upon http://snippsnapp.polite.se/wiki?PyPodcastGen
# This script is public domain

import os,datetime,urlparse,urllib
import PyRSS2Gen


class Podcastfile:
	def __init__(self, collection, basename):
		self.basename = basename
		self.path = os.path.join(collection.dirname, basename)
		self.link = urlparse.urljoin(collection.urlbase, urllib.quote(basename))
		self.title = basename[:-4] # strip three-letter extension
		self.description = basename[:-4]
		self.guid = PyRSS2Gen.Guid(self.link)
		self.size = os.path.getsize(self.path)

		extension = basename[-3:]
		if extension == "mp3":
			self.mimetype = "audio/mpeg"
		elif extension == "m4a":
			self.mimetype = "audio/x-m4a"
		else:
			self.mimetype = "application/octet-stream"

		self.enclosure = PyRSS2Gen.Enclosure(self.link, self.size, self.mimetype)
		self.pubdate = datetime.datetime.fromtimestamp(os.path.getmtime(self.path))


class Podcastfiles:
	def __init__(self, urlbase, title, link, description, language):
		self.urlbase = urlbase
		self.title = title
		self.link = link
		self.description = description
		self.language = language

		self.data = []

		self.generator = PyRSS2Gen._generator_name

	def append(self,Podcastfile):
		self.data.append(Podcastfile)

	def readfolder(self,dirname):
		self.dirname = dirname
		files = os.listdir(dirname)
		for f in files:
			path = os.path.join(dirname,f)
			if os.path.exists(path) and os.path.isfile(path) and (path.endswith(".mp3") or path.endswith(".m4a")):
				podcastfile = Podcastfile(self, f)
				self.append(podcastfile)

	def rssitems(self,n=10):
		result = []
		for Podcastfile in self.data:
			rssitem = PyRSS2Gen.RSSItem(title = Podcastfile.title,
										link = Podcastfile.link,
										description = Podcastfile.description,
										guid = Podcastfile.guid,
										pubDate = Podcastfile.pubdate,
										enclosure = Podcastfile.enclosure)
			result.append(rssitem)

		waste = [(i.pubDate,i) for i in result]
		waste.sort()
		waste.reverse()
		waste = waste[:n]
		result = [pair[1] for pair in waste]

		return result

	def getrss(self):
		return PyRSS2Gen.RSS2(title = self.title,
				link = self.link,
				description = self.description,
				language = self.language,
				generator = self.generator,
				lastBuildDate = datetime.datetime.now(),
				items = self.rssitems())


if __name__ == "__main__":
	#Example usage

	Podcastfiles = Podcastfiles("http://path/to/mp3/",
			"A title for your podcast",
			"http://yourdomain.com/aboutyourpodcast",
			"A long winded description of your very fine podcast",
			"en")

	Podcastfiles.readfolder("/path/to/your/mp3/folder")
	outfilename = "/path/to/your/feedfile.xml"

	rss = Podcastfiles.getrss()
	rss.write_xml(open(outfilename, "w"))
