#!/usr/bin/env python

# Generate a podcast feed from the specified (or current)
# folder's contents
# By Kevin Yank <thatguy@kevinyank.com>
# Based upon http://snippsnapp.polite.se/wiki?PyPodcastGen
# This script is public domain

import sys,os,urllib
import PyPodcastGen


# Command-line arguments

directory = os.getcwd()
if len(sys.argv) > 1:
	directory = os.path.abspath(sys.argv[1])

podcastTitle = "Folder: " + os.path.dirname(directory)
if len(sys.argv) > 2:
	podcastTitle = sys.argv[2]

podcastURL = ""
if len(sys.argv) > 3:
	podcastURL = sys.argv[3]

baseURL = "http://localhost/"
if len(sys.argv) > 4:
	baseURL = sys.argv[4]

Podcastfiles = PyPodcastGen.Podcastfiles(
		baseURL,
		podcastTitle,
		podcastURL,
		"Podcast from folder: " + os.path.abspath(directory),
		"en")

Podcastfiles.readfolder(directory)
rss = Podcastfiles.getrss()

rss.write_xml(open(os.path.join(directory, "podcast.xml"), "w"))
